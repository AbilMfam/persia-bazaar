import { existsSync, readFileSync, writeFileSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

/**
 * Capacitor’s Android library has its own buildscript repositories. If dl.google.com
 * is unreachable from your network, preprend Aliyun mirrors so AGP resolves like the app project.
 */
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const target = path.join(root, "node_modules", "@capacitor", "android", "capacitor", "build.gradle");

const needle = `buildscript {
    repositories {
        google()`;

const replacement = `buildscript {
    repositories {
        maven { url 'https://maven.aliyun.com/repository/google' }
        maven { url 'https://maven.aliyun.com/repository/central' }
        google()`;

function main() {
  if (!existsSync(target)) {
    return;
  }
  let text = readFileSync(target, "utf8");
  if (text.includes("maven.aliyun.com")) {
    return;
  }
  if (!text.includes(needle)) {
    console.warn("[ensure-capacitor-gradle-repos] @capacitor/android build.gradle layout changed; skipping patch");
    return;
  }
  writeFileSync(target, text.replace(needle, replacement), "utf8");
  console.log("[ensure-capacitor-gradle-repos] Patched @capacitor/android build.gradle (Maven mirrors)");
}

main();
